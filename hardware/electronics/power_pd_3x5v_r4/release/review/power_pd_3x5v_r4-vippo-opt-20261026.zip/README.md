# R4 盘中孔优化

版本：R4-VIPPO-OPT-20261026

R4 从 `power_pd_3x5v_r3` 隔离复制，只优化过孔和局部接地走线，保留 82 × 55.8 × 1.2 mm 四层板框、USB-C 接口、安装孔、93 个封装、所有焊盘位置和原理图电气连接。

## 结果

- SMD 铜/阻焊/钢网焊盘内过孔：0
- DRC 违规：0
- 未连接：0
- 板边/封装位置检查：通过
- R3 焊盘与封装合同：完全一致
- 过孔数量：R3 101 个，R4 99 个

R4 只解决 PCB 侧的盘中孔问题；芯片散热焊盘仍通过焊盘外的 GND 过孔和铜区散热。正式下单前仍需华秋 CAM 确认阻焊桥、钢网开口、孔环和散热铜连接。

## 文件

- `power_pd_3x5v_r4.kicad_pcb`：优化后的源板
- `power_pd_3x5v_r4.kicad_pro`：沿用 R3 设计规则
- `GaugePower.pretty/`、`fp-lib-table`：封装资源
- `production/gerbers/`：R4 Gerber 与钻孔文件
- `production/power_pd_3x5v_r4-pos.csv`：贴片坐标
- `production/reference/`：R3 原理图 PDF/BOM 参考，原理图未改动
- `verification/VIA_IN_PAD_REVIEW.json`：盘中孔扫描结果
- `verification/current/`：SHA 绑定 DRC 报告
- `task_plan.md`：调整记录

R4 尚未替换 R3 的生产包；需在华秋 CAM 审核通过后，再生成新的 SMT/BOM/生产 ZIP。

