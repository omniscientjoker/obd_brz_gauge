# PCB + SMT 制造交付：R4-VIPPO-OPT-20261026-R1

R4 是 R3 的盘中孔优化版。PCB、封装、焊盘、元件位置、原理图和采购物料合同保持不变；仅迁移/删除过孔并重新导出制造层。4层板，82 × 55.8 × 1.2 mm；82件双面SMT（Top31、Bottom51），4件通孔后焊，总86件、31种制造商MPN。

| 下单环节 | 使用文件 |
| --- | --- |
| PCB裸板 | `PCB_GERBER.zip`，4铜层、双面阻焊/丝印/锡膏、Edge.Cuts、PTH/NPTH钻孔及Gerber Job，共14文件 |
| 双面SMT | `assembly/BOM_SMT.csv` + `assembly/CPL_SMT.csv` |
| 通孔后焊 | `assembly/BOM_THT.csv` + `assembly/THT_POSITION.csv` |
| 一站式全料代采 | `assembly/BOM_ALL.csv`，不要与拆分BOM重复导入 |
| 工艺核对 | `ORDER_PARAMETERS.md`、`ASSEMBLY_NOTES.md`、`assembly/ASSEMBLY_TOP_BOTTOM.pdf`、`assembly/PIN1_POLARITY.csv` |
| 盘中孔 | `pcb/VIPPO_HOLES.csv` 为空表；R4 检出0个SMD焊盘内过孔，不要求VIPPO |
| 首板验收 | `FIRST_ARTICLE_TEST.md` |
| 完整性 | `SHA256.json` |

CPL单位mm，两面统一顶视；X=KiCadX−59，Y=127.5−KiCadY。Bottom不另作坐标镜像。R4坐标由当前 R4 PCB 经 KiCad MCP 重新导出。

输入必须实际提供固定15V PDO；三路约5V、每路1.5A为设计目标。首板带载、纹波、保护和封闭底盒温升仍需实物验收。
