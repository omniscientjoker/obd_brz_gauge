# 华秋 PCB + PCBA 打样下单说明

版本：R4-HUAQIU-20261026-R1；4层、82×55.8×1.2mm；双面SMT 82件（Top31/Bottom51）+ THT后焊4件；31种MPN。

1. 上传 `01_PCB/PCB_GERBER.zip` 做裸板报价。选择4层、FR-4、成品1.2mm、内外层目标1oz、无铅沉金、绿油双面白字。R4无盘中孔，`01_PCB/VIPPO_HOLES.csv`为空表。
2. SMT上传 `02_SMT/BOM_HUAQIU_SMT.xlsx` 或同名CSV二选一，并上传 `02_SMT/CPL_SMT.csv`；如平台要求分面，改用 `CPL_TOP.csv` 和 `CPL_BOTTOM.csv`，不要与合并CPL重复导入。
3. THT上传 `03_THT/BOM_HUAQIU_THT.csv` 和 `03_THT/THT_POSITION.csv`，J1/J2/J3/J4在双面回流后焊接。
4. 首件附件使用 `04_ASSEMBLY/ASSEMBLY_TOP_BOTTOM.pdf`、`PIN1_POLARITY.csv`、`SCHEMATIC.pdf`、`ORDER_PARAMETERS.md` 和 `ASSEMBLY_NOTES.md`。`BOM_HUAQIU_ALL.csv`可作为86件总BOM替代拆分BOM，不能重复导入。
5. 订单备注见 `HUAQIU_ORDER_REMARKS.txt`。BOM是单板用量，板数、损耗、库存和替料由华秋接单时确认；不得混用R3资料。

R4 源板 DRC：0违规、0未连接；下单前仍需华秋 CAM 复核阻焊桥、钢网开口、拼板、元件库零度和实物首板带载/温升。
