# 华秋 PCB + SMT + 通孔后焊下单包

交付版本：R4-HUAQIU-20261026-R1。电气版本：R4-ERC-20261026。4层板，82×55.8×1.2mm，内外层目标1oz，沉金；R4无盘中孔，普通过孔按Gerber钻孔文件制造。

每板82件双面SMT（正面31、背面51）＋4件通孔后焊，共86件、31种制造商MPN。BOM数量均为单板用量，订单板数、贴片损耗及代采余量由华秋平台确认。

## 上传顺序

| 环节 | 上传文件 | 操作 |
| --- | --- | --- |
| PCB报价 | `01_PCB/PCB_GERBER.zip` | 上传Gerber ZIP；选择4层、1.2mm、内外1oz、沉金；R4不要求VIPPO |
| SMT BOM | `02_SMT/BOM_HUAQIU_SMT.xlsx` 或同名CSV | 二选一导入，单板82件 |
| SMT坐标 | `02_SMT/CPL_SMT.csv` | 双面82件；平台要求分面时使用TOP/BOTTOM文件，不叠加 |
| 通孔后焊 | `03_THT/BOM_HUAQIU_THT.csv` + `03_THT/THT_POSITION.csv` | J1/J2/J3/J4在双面回流后安装 |
| 工艺附件 | `HUAQIU_ORDER_GUIDE.md`、`04_ASSEMBLY/ASSEMBLY_TOP_BOTTOM.pdf`、`04_ASSEMBLY/PIN1_POLARITY.csv` | 用于首件核对 |
| 首板验收 | `05_TEST/FIRST_ARTICLE_TEST.md` | 首板完成后记录带载、纹波和温升 |

R4的 `01_PCB/VIPPO_HOLES.csv` 为空表，表示0个SMD焊盘内过孔；仍需按Gerber/CAM确认普通过孔、阻焊桥、钢网开口和拼板工艺。不得混用R3的Gerber、BOM或CPL。包内SHA256.json记录交付文件哈希及R4源板指纹；未代替华秋在线导入、库存确认或首板实物测试。
