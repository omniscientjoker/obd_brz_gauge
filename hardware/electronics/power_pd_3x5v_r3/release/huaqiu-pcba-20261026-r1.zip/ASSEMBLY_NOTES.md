# 双面SMT与通孔后焊

适用R3-HUAQIU-20261026-R1。使用同包Gerber、BOM、CPL及双面装配PDF。

- `02_SMT/BOM_HUAQIU_SMT.csv`为82件，`03_THT/BOM_HUAQIU_THT.csv`为4件；`04_ASSEMBLY/BOM_HUAQIU_ALL.csv`为两者合计86件，仅选择一套代采方式，避免重复导入。H1/H2与TP*不采购。
- 按制造商及完整MPN采购。0.1%电阻不改为1%；ROVINH=133k/0.1%，RLIM2/3/4=84.5k/1%，RILM2/3/4=1.65k/1%。
- L2/L3/L4为Coilcraft XAL5050-682MEC；不按标称电感量替换焊盘、饱和特性和温升不同的物料。无电气极性，建议标记引出端朝SW焊盘1。
- CBULK1/2/3=Panasonic 35SVPK82M；CE2/3/4=Panasonic 25SVPF100M；正极为pad1，按厂家卷带图认方向，不把负极外观标记当正极。
- DTVS=SMAJ16A-E3/61单向TVS；pad1为阴极，接输入正电源；pad2接地。不得改为双向型号。
- UPD=CH224A，手册EP0对应PCB11；CFG2/CFG3有意悬空，不加电阻。U2/U3/U4=RT7272BGSP，PSOP-8 Option2、EP9接地；UP2/3/4=TPS259470LRPWR，保留L锁存型号；UIN=TPS26630RGER。禁止使用引脚或保护策略不同的近似型号。
- 先双面回流，再安装4件通孔连接器。J1为GCT USB4085-GF-A，16接点及4个SH固定脚全部后焊；检查0.85mm接点间距桥连。J2/J3/J4为JST卧式XH，pin1=受保护+5V，pin2=GND。
- CPL单位mm，两面统一顶视，X向右、Y向上；原点为KiCad(59,127.5)，中央凸舌最低Y=−0.3mm。Bottom装配PDF为背视镜像，CPL不再镜像。封装原点及原生角度须由工厂按元件库核对取料中心、偏移和零度。
- `04_ASSEMBLY/PIN1_POLARITY.csv`给出引脚焊盘中心和网络，用于方向核对；它不是CPL，不应用作贴装中心。
- 聚合物电容、重电感和连接器按所购实物的回流温度及重复回流限制安排工序；检查QFN/EP锡膏转移、空洞和润湿。
- 盘中孔先按 `01_PCB/VIPPO_HOLES.csv` 和Gerber完成树脂塞孔、填平、盖铜，再进行贴装。钢网按双面Paste层，由工厂确认厚度和EP开窗。

额定耐压、介质、精度、ESR/纹波、电感偏置及IC完整后缀均属于采购约束。首板按 `05_TEST/FIRST_ARTICLE_TEST.md`验收；当前未完成实物带载、瞬态及温升资格验证。
