# 华秋 PCB + SMT + 通孔后焊下单包

交付版本：R3-HUAQIU-20261026-R1。电气版本：R3-ERC-20261026。4层板，82×55.8×1.2mm，内外层目标1oz，沉金，VIPPO树脂塞孔填平盖铜。

每板82件双面SMT（正面31、背面51）＋4件通孔后焊，共86件、31种制造商MPN。BOM数量均为单板用量，订单板数在华秋平台填写，贴片损耗及代采余量由工厂另计。H1/H2和TP*不采购、不贴装。

## 上传顺序

| 环节 | 上传文件 | 操作 |
| --- | --- | --- |
| PCB报价 | [01_PCB/PCB_GERBER.zip](01_PCB/PCB_GERBER.zip) | 上传内部Gerber ZIP；选择4层、1.2mm、内外1oz、沉金，提供VIPPO要求 |
| SMT BOM | [02_SMT/BOM_HUAQIU_SMT.xlsx](02_SMT/BOM_HUAQIU_SMT.xlsx) | 单工作表，第一行即华秋官方九列表头。与同名CSV二选一导入，单板82件 |
| SMT坐标 | [02_SMT/CPL_SMT.csv](02_SMT/CPL_SMT.csv) | 双面82件；平台要求分面时改用CPL_TOP.csv和CPL_BOTTOM.csv，两种方式不叠加 |
| 通孔后焊 | [03_THT/BOM_HUAQIU_THT.csv](03_THT/BOM_HUAQIU_THT.csv)、[03_THT/THT_POSITION.csv](03_THT/THT_POSITION.csv) | 单独确认4个连接器的代采及后焊，J1/J2/J3/J4均在双面回流后安装 |
| 工艺附件 | [HUAQIU_ORDER_GUIDE.pdf](HUAQIU_ORDER_GUIDE.pdf)、[04_ASSEMBLY/ASSEMBLY_TOP_BOTTOM.pdf](04_ASSEMBLY/ASSEMBLY_TOP_BOTTOM.pdf)、[04_ASSEMBLY/PIN1_POLARITY.csv](04_ASSEMBLY/PIN1_POLARITY.csv)、[01_PCB/VIPPO_HOLES.csv](01_PCB/VIPPO_HOLES.csv) | 整包作为工艺附件交付，工厂核对器件面别、元件库零度、取料中心及盘中孔处理范围 |
| 订单备注 | [HUAQIU_ORDER_REMARKS.txt](HUAQIU_ORDER_REMARKS.txt) | 可复制到订单备注，再将详细工艺文件作为附件 |
| 首板验收 | [05_TEST/FIRST_ARTICLE_TEST.md](05_TEST/FIRST_ARTICLE_TEST.md) | 明确委托工厂测试的项目，完成首板后再扩大生产 |

如华秋业务按一份总BOM承接整板代采，可使用 `04_ASSEMBLY/BOM_HUAQIU_ALL.csv` 替代SMT与THT两份BOM，共86件；不要与拆分BOM重复导入。`04_ASSEMBLY/SCHEMATIC.pdf`用于后焊和测试核对。

## 生产必须确认的项目

1. 按厂家及完整MPN采购；BOM不含未经核实的商城编号。无库存料、起订量和损耗余量由华秋报价确认，替料须重新核准。
2. 双面回流后焊接J1 USB4085-GF-A全通孔USB-C与J2/J3/J4 XH端子。J1的16个接点和4个SH固定脚全部焊接，不能替用旧HRO母座。
3. 27个VIPPO候选孔来自保守相交筛选，工厂按实际Gerber/CAM确认处理孔。必须树脂塞孔、填平、盖铜，普通盖油不能替代。
4. 坐标单位mm，Top/Bottom均为顶视，Bottom不再镜像。封装角度和原点由华秋按贴片机元件库转换，按极性表及双面图核对首件。CPL原点与Gerber/钻孔原点不同，关系详见PDF。
5. 工厂安排双面钢网、工艺边、Mark、拼板或载具，禁止改变单板板框、USB凸舌和安装孔。钢网优先0.10mm，最终开口及EP分窗由工厂确认。

## 核验与使用边界

包内SHA256.json记录所有交付文件及对应源设计指纹。原设计DRC为0违规、0未连接，ERC为0违规；本次仅做华秋资料适配，PCB、布线、Gerber和物料值未改变。未代替用户上传、付款或向工厂发送消息。

输入需实际支持固定15V PDO，三路约5V、每路1.5A为设计目标。部分X5R电容最高85°C，带载、纹波、保护及封闭底盒温升尚待实物验收；本包用于首板制作与工艺审核。

华秋官方BOM模板：<https://smt.hqchip.com/uploads/bom.xls>。本次下载核对了九列表头及“待匹配BOM放在第一个工作表”的要求，实际平台识别、代采和后焊工艺由华秋接单时确认。
