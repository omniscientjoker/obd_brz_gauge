# PCB + SMT 制造交付：R3-PRODUCTION-20261026-R1

本包由已核验的 R3-ERC-20261026 资料精简，电路、PCB、Gerber、物料和坐标均未变更。4层板，82×55.8×1.2mm；82件双面SMT（Top31、Bottom51），4件通孔后焊，总86件、31种制造商MPN。

| 下单环节 | 使用文件 |
| --- | --- |
| PCB裸板 | `PCB_GERBER.zip`，内含4铜层、双面阻焊/丝印/锡膏、板框、PTH/NPTH钻孔及Gerber Job，共14文件 |
| 双面SMT代采与贴装 | `assembly/BOM_SMT.csv` + `assembly/CPL_SMT.csv` |
| 通孔后焊 | `assembly/BOM_THT.csv` + `assembly/THT_POSITION.csv`，J1/J2/J3/J4共4件 |
| 一站式全料代采 | `assembly/BOM_ALL.csv` 可代替两份拆分BOM；不要与拆分BOM同时导入 |
| 工艺与贴装核对 | `ORDER_PARAMETERS.md`、`ASSEMBLY_NOTES.md`、`assembly/ASSEMBLY_TOP_BOTTOM.pdf`、`assembly/PIN1_POLARITY.csv` |
| 盘中孔加工 | `pcb/VIPPO_HOLES.csv`，27个候选孔，由CAM确认并执行树脂塞孔、填平、盖铜 |
| 首板验收 | `FIRST_ARTICLE_TEST.md` |
| 资料完整性 | `SHA256.json`；记录制造文件哈希及对应源板/原理图/规则指纹 |

PCB报价先上传内层 `PCB_GERBER.zip`；SMT再上传同包BOM和CPL并附装配资料。外层整包用于工艺附件交付。BOM为UTF-8 BOM编码、华秋九列表头CSV，其他平台按列映射导入。

CPL单位mm，两面统一顶视：X=KiCadX−59，Y=127.5−KiCadY。Bottom不另作坐标镜像；装配PDF底面图是背视。角度和封装原点须由工厂转换为贴片机元件库零度及取料中心。

输入板载CH224A请求固定15V，电源必须实际提供15V PDO。三路约5V、每路1.5A为设计目标；下单制作首板后按验收文件测试，尚未完成实物电源性能及车内高温验证。部分X5R器件最高85°C。

本次源板重新DRC为0违规、0未连接，原理图重新ERC为0违规。工程源文件、模型、渲染图及历史审核记录不进入交厂包。
